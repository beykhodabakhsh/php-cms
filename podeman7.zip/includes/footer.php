</div>
<div class="footer-section-g">
    <div class="back-dark">
        <p>© تمامی حقوق متعلق به گروه ایرانی شاپ می باشد.</p>
    </div>
</div>
<script src="scripts/jquery.js"></script>
<script src="scripts/carousel.min.js"></script>
<script src="scripts/scripts.js"></script>
<script src="scripts/popper.js"></script>
<script src="scripts/bootstrap.min.js"></script>
</body>
</html>
